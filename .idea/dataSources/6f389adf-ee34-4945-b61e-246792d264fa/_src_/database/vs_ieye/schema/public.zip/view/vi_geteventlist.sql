CREATE VIEW vi_geteventlist AS SELECT ti_guard_plan.guard_plan_name,
    ti_event.event_id,
    ti_event.event_no,
    ti_event.event_genus,
    ti_event.event_name,
    ti_event.event_desc,
    ti_event.enable_state,
    ti_event.event_level,
    ti_event.auto_release_interval,
    ti_event.guard_plan_id,
    ti_guard_plan.guard_plan_type,
    ti_guard_plan.time_schedule,
    ti_guard_plan.start_time,
    ti_guard_plan.end_time
   FROM (ti_event
     JOIN ti_guard_plan ON ((ti_event.guard_plan_id = ti_guard_plan.guard_plan_id)));
