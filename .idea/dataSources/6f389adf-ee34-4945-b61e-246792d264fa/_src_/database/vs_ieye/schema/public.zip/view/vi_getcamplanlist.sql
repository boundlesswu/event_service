CREATE VIEW vi_getcamplanlist AS SELECT DISTINCT a.res_id,
    a.res_name,
    a.chn_type,
    b.group_id,
    d.rec_plan_id,
    d.rec_plan_name,
    d.enable_state,
    d.stream_type,
    d.rec_path
   FROM (((ti_resource a
     LEFT JOIN tr_group_res b ON ((a.res_id = b.res_id)))
     LEFT JOIN tr_record_plan_cam c ON ((c.res_id = a.res_id)))
     LEFT JOIN ti_record_plan d ON ((d.rec_plan_id = c.rec_plan_id)));
