CREATE VIEW vi_getswitchtasklist AS SELECT a.switch_task_id,
    a.task_name,
    a.wall_id,
    a.task_no,
    b.name
   FROM (ti_switch_task a
     LEFT JOIN ti_video_wall b ON ((a.wall_id = b.wall_id)));
