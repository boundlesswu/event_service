CREATE VIEW vi_getiaaggrouplist AS SELECT a.iaag_chn_id,
    a.svr_id,
    a.res_id,
    a.preset_no,
    b.res_no,
    b.res_name,
    c.preset_name
   FROM ((tr_iaag_cam a
     JOIN ti_resource b ON ((a.res_id = b.res_id)))
     LEFT JOIN ti_preset c ON (((c.res_id = a.res_id) AND ((a.preset_no)::text = (c.preset_no)::text))));
