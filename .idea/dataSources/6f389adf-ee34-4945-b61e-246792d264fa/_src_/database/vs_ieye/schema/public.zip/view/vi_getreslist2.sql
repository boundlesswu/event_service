CREATE VIEW vi_getreslist2 AS SELECT DISTINCT a.res_id,
    a.res_no,
    a.res_name,
    a.res_type,
    a.dev_id,
    a.res_uid,
    a.chn_type,
    a.remark,
    b.name,
    c.dev_name
   FROM ((ti_resource a
     LEFT JOIN td_resource_type b ON (((a.res_type)::text = (b.refvalue)::text)))
     LEFT JOIN ti_device c ON ((c.dev_id = a.dev_id)));
