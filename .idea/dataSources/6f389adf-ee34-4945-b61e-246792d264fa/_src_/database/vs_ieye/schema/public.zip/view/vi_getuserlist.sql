CREATE VIEW vi_getuserlist AS SELECT ti_user.user_id,
    ti_user.username,
    ti_user.nickname,
    ti_user.user_type,
    ti_user.create_time,
    ti_user.flag_locked
   FROM ti_user;
