CREATE VIEW vi_getcamplanlist2 AS SELECT a.res_id,
    a.res_name,
    a.chn_type,
    d.rec_plan_id,
    d.rec_plan_name,
    d.enable_state,
    d.stream_type,
    d.rec_path
   FROM ((ti_resource a
     LEFT JOIN tr_record_plan_cam c ON ((c.res_id = a.res_id)))
     LEFT JOIN ti_record_plan d ON ((d.rec_plan_id = c.rec_plan_id)));
