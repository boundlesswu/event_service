CREATE VIEW vi_getgrouplist AS SELECT a.group_id,
    a.group_no,
    a.group_name,
    a.group_type,
    a.parent_group_id,
    b.group_name AS parentname
   FROM (ti_group a
     LEFT JOIN ti_group b ON ((a.parent_group_id = b.group_id)));
