CREATE VIEW vi_getdevlist AS SELECT a.dev_id,
    a.dev_no,
    a.svr_id,
    a.dev_name,
    a.dev_type,
    a.protocol_type,
    a.dev_sn,
    a.group_id,
    a.remark,
    b.group_name,
    c.name,
    d.refvalue,
    e.online_state
   FROM ((((ti_device a
     LEFT JOIN ti_group b ON ((a.group_id = b.group_id)))
     LEFT JOIN td_device_type c ON (((c.refvalue)::text = (a.dev_type)::text)))
     LEFT JOIN td_device_type d ON ((d.id = c.parentid)))
     LEFT JOIN ti_dev_state e ON ((e.dev_id = a.dev_id)));
