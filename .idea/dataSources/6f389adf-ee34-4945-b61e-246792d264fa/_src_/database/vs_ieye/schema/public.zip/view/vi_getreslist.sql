CREATE VIEW vi_getreslist AS SELECT DISTINCT a.res_id,
    a.res_no,
    a.res_name,
    a.res_type,
    a.dev_id,
    a.res_uid,
    a.chn_type,
    a.remark,
    b.group_id,
    c.dev_name,
    d.name
   FROM (((ti_resource a
     LEFT JOIN tr_group_res b ON ((a.res_id = b.res_id)))
     LEFT JOIN ti_device c ON ((c.dev_id = a.dev_id)))
     LEFT JOIN td_resource_type d ON (((a.res_type)::text = (d.refvalue)::text)));
