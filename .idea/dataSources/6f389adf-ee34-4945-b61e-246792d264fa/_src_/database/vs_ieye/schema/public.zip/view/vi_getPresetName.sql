CREATE VIEW "vi_getPresetName" AS SELECT tr_iaag_cam.preset_no,
    tr_iaag_cam.iaag_chn_id,
    tr_iaag_cam.svr_id,
    tr_iaag_cam.res_id,
    ti_preset.preset_name,
    ti_preset.preset_token
   FROM tr_iaag_cam,
    ti_preset;
