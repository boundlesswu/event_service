CREATE VIEW vi_getiaag_cam_by_user AS SELECT DISTINCT a.group_id,
    d.res_id,
    e.res_name,
    f.svr_id,
    f.svr_name,
    g.user_id
   FROM (((((tr_role_group a
     JOIN tr_group_res c ON ((c.group_id = a.group_id)))
     JOIN tr_iaag_cam d ON ((d.res_id = c.res_id)))
     JOIN ti_resource e ON ((e.res_id = d.res_id)))
     JOIN ti_server f ON ((f.svr_id = d.svr_id)))
     JOIN tr_user_role g ON ((g.role_id = a.role_id)));
